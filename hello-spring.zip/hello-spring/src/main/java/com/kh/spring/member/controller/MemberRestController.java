package com.kh.spring.member.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.kh.spring.member.model.service.MemberService;
import com.kh.spring.member.model.vo.Member;



/**
 * data를 직접 응답메세지에 출력
 * 
 *
 */
@RestController
@RequestMapping("/member")
public class MemberRestController {

	@Autowired
	private MemberService memberService;
	
	@GetMapping("/selectOneMember.do")
	@ResponseBody
	public ResponseEntity<?> selectOneMember(@RequestParam String id) {
		Member member = memberService.selectOneMember(id);
		if(member != null)
			return ResponseEntity.ok(member);
		else 
			return ResponseEntity.notFound().build();
	}
	
	@GetMapping("/findMemberByName.do")
	public List<Member> findMemberByName(@RequestParam String query) {
		
		return memberService.findMemberByName(query);
	}
}
