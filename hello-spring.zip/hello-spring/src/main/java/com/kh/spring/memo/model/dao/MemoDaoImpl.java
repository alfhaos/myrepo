package com.kh.spring.memo.model.dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.kh.spring.memo.model.vo.Memo;

import lombok.extern.slf4j.Slf4j;

@Repository
@Slf4j
public class MemoDaoImpl implements MemoDao {

	
	@Autowired
	private SqlSessionTemplate session;

	@Override
	public int insertMemo(Memo mm) {
		// TODO Auto-generated method stub
		return session.insert("memo.insertMemo",mm);
	}

	@Override
	public List<Memo> selectMemoList() {
		log.debug("dao 주업무");
		// TODO Auto-generated method stub
		return session.selectList("memo.selectMemoList");
	}

	@Override
	public int deleteMemo(int no) {
		// TODO Auto-generated method stub
		return session.delete("memo.deleteMemo",no);
	}

	@Override
	public Memo selectOneMemo(int no) {
		// TODO Auto-generated method stub
		return session.selectOne("memo.selectOneMemo",no);
		
	}
	
	
	
	
	
	
}
