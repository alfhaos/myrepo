package com.kh.spring.memo.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.kh.spring.memo.model.dao.MemoDao;
import com.kh.spring.memo.model.vo.Memo;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MemoServiceImpl implements MemoService {

	@Autowired
	private MemoDao memoDao;
	
	
	@Override
	public int insertMemo(Memo mm) {
		// TODO Auto-generated method stub
		return memoDao.insertMemo(mm);
	}


	@Override
	public List<Memo> selectMemoList() {
		log.debug("서비스 주업무");
		// TODO Auto-generated method stub
		return memoDao.selectMemoList();
	}


	@Override
	public int deleteMemo(int no) {
		// TODO Auto-generated method stub
		return memoDao.deleteMemo(no);
	}


	@Override
	public Memo selectOneMemo(int no) {
		// TODO Auto-generated method stub
		return memoDao.selectOneMemo(no);
	}
	
	

	
	
}
