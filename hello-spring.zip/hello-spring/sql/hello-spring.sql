--========================================================================
-- 관리자계정
--========================================================================
alter session set "_oracle_script" = true; -- 일반사용자 c## 접두어 없이 계정생성


create user spring
identified by spring
default tablespace users;


alter user spring quota UNLIMITED on users;


grant connect, resource to spring;


--==========================================
-- spring계정
--==========================================
--dev 테이블
create table dev(
    no number,
    name varchar2(50) not null,
    career number not null,
    email varchar2(200) not null,
    gender char(1),
    lang varchar2(100) not null, -- vo String[] <---> varchar2 'java.c.js'
    
    constraint pk_dev_no primary key(no),
    constraint ck_dev_gender check(gender in ('M','F'))

);

create sequence seq_dev_no;

select
    *
from 
    dev;


-- 회원테이블 생성
-- member_role은
create table member (
    id varchar2(15),
    password varchar2(300) not null,
    name varchar2(256) not null,
    gender char(1),
    birthday date,
    email varchar2(256),
    phone char(11) not null,
    address varchar2(512),
    hobby varchar2(256),
    enroll_date date default sysdate,
    enabled number default 1,       -- 회원활성화여부 1: 활성화됨, 0:비활성화(spring-security)
    constraint pk_member_id primary key(id),
    constraint ck_member_gender check(gender in ('M','F')),
    constraint ck_member_enabled check(enabled in (1,0))
);
	insert into spring.member values ('abcde','1234','아무개','M',to_date('88-01-25','rr-mm-dd'),'abcde@naver.com','01012345678','서울시 강남구','운동,등산,독서',default,default);
	insert into spring.member values ('qwerty','1234','김말년','F',to_date('78-02-25','rr-mm-dd'),'qwerty@naver.com','01098765432','서울시 관악구','운동,등산',default,default);
	insert into spring.member values ('admin','1234','관리자','F',to_date('90-12-25','rr-mm-dd'),'admin@naver.com','01012345678','서울시 강남구','독서',default,default);
	commit;
select * from member where name like '%홍%';


--delete from member where id = 'honggd';
--commit;



create table memo (
   no number,
    memo varchar2(2000),
    password char(4) not null,
    reg_date date default sysdate,
    constraint pk_memo_no primary key(no
);

create sequence seq_memo_no;

insert into memo values(seq_memo_no.nextval, '안녕하세요~ 반갑습니다.', '1234', default);

insert into memo values(seq_memo_no.nextval, '파이널프로젝트 화이팅!.', '1234', default);
insert into memo values(seq_memo_no.nextval, '여보세요!.', '1234', default);


--board/attachment
--board 테이블
	create table board (
		no number,
		title varchar2(200),
		member_id varchar2(15),
		content varchar2(2000),
		reg_date date default sysdate,
		read_count number default 0,
		constraint pk_board_no primary key(no),
		constraint fk_board_member_id foreign key(member_id) 
							 references member(id)
							 on delete set null
	);

	create sequence seq_board_no;

	--attachment 테이블
	create table attachment (
		no number,
		board_no number not null,
		original_filename varchar2(256) not null,
		renamed_filename varchar2(256) not null,
		upload_date date default sysdate,
		download_count number default 0,
		status char(1) default 'Y',
		constraint pk_attachment_no primary key(no),
		constraint fk_attachment_board_no foreign key(board_no) 
							 references board(no)
							 on delete cascade,
		constraint ck_attachment_status check(status in ('Y','N'))
	);

	create sequence seq_attachment_no;

select * from board;
select * from attachment;




-- 게시판 목록

select
    b.*,
    (select count(*) from attachment where board_no = b.no) attach_count
from
    board  b
order by
    no desc;


select count(*) from attachment where board_no = 55;

	 	select
		    b.*,
		    (select count(*) from attachment where board_no = b.no) attach_count
		from
		    board b
		order by
		    no desc;
 	

commit;

-- 게시판 첨부파일 join 쿼리
select
    b.*,
    a.*,
    a.no as attach_no
from
    board b left join attachment a on b.no = a.board_no;
    
    
select
    *
from
    member m join board b on 'honggd' = b.member_id;